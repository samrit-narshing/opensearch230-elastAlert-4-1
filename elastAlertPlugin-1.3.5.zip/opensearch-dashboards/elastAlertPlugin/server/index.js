"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.plugin = plugin;
Object.defineProperty(exports, "ElastAlertPluginPluginSetup", {
  enumerable: true,
  get: function () {
    return _types.ElastAlertPluginPluginSetup;
  }
});
Object.defineProperty(exports, "ElastAlertPluginPluginStart", {
  enumerable: true,
  get: function () {
    return _types.ElastAlertPluginPluginStart;
  }
});

var _plugin = require("./plugin");

var _types = require("./types");

// This exports static code and TypeScript types,
// as well as, OpenSearch Dashboards Platform `plugin()` initializer.
function plugin(initializerContext) {
  return new _plugin.ElastAlertPluginPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInBsdWdpbiIsImluaXRpYWxpemVyQ29udGV4dCIsIkVsYXN0QWxlcnRQbHVnaW5QbHVnaW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTs7QUFTQTs7QUFQQTtBQUNBO0FBRU8sU0FBU0EsTUFBVCxDQUFnQkMsa0JBQWhCLEVBQThEO0FBQ25FLFNBQU8sSUFBSUMsOEJBQUosQ0FBMkJELGtCQUEzQixDQUFQO0FBQ0QiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQgfSBmcm9tICcuLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgRWxhc3RBbGVydFBsdWdpblBsdWdpbiB9IGZyb20gJy4vcGx1Z2luJztcblxuLy8gVGhpcyBleHBvcnRzIHN0YXRpYyBjb2RlIGFuZCBUeXBlU2NyaXB0IHR5cGVzLFxuLy8gYXMgd2VsbCBhcywgT3BlblNlYXJjaCBEYXNoYm9hcmRzIFBsYXRmb3JtIGBwbHVnaW4oKWAgaW5pdGlhbGl6ZXIuXG5cbmV4cG9ydCBmdW5jdGlvbiBwbHVnaW4oaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcbiAgcmV0dXJuIG5ldyBFbGFzdEFsZXJ0UGx1Z2luUGx1Z2luKGluaXRpYWxpemVyQ29udGV4dCk7XG59XG5cbmV4cG9ydCB7IEVsYXN0QWxlcnRQbHVnaW5QbHVnaW5TZXR1cCwgRWxhc3RBbGVydFBsdWdpblBsdWdpblN0YXJ0IH0gZnJvbSAnLi90eXBlcyc7XG4iXX0=